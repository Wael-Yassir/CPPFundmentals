bool IsPrime(int x);

bool Is2MorePrime(int const& x);

//int& BadFunction();