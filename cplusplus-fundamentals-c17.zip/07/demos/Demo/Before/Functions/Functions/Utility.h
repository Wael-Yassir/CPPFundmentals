bool IsPrime(int x);

bool Is2MorePrime(int x);

//int& BadFunction();