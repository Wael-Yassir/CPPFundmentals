#include "Resource.h"
using std::string;

Resource::Resource(string n):name(n)
{
}


Resource::~Resource()
{
}
