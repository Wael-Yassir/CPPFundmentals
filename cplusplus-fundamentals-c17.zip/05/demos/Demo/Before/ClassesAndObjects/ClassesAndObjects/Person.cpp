#include "Person.h"

std::string Person::getName()
{
	return firstname + " " + lastname;
}
