// ClassesAndObjects.cpp : Defines the entry point for the console application.
//

#include "Person.h"

int main()
{
	Person p1;
	Person p2;
	std::string name = p1.getName();

	//int i = p1.arbitrarynumber;

	return 0;
}

