#include <string>
class Person
{
private:
	std::string firstname;
	std::string lastname;
	int arbitrarynumber;

public:
	std::string getName();

};