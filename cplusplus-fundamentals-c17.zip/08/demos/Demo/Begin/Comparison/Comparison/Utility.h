#include <string>
using std::string;

bool IsPrime(int x);
int foo(string s);
int something();

