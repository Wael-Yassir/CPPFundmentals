bool IsPrime(int x);

