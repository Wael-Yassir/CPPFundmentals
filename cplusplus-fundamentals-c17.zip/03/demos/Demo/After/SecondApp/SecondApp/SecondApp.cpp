// SecondApp.cpp : Defines the entry point for the console application.
//


int main()
{
    return 0;
}

